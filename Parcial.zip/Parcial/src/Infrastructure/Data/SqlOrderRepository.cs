using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;

namespace Infrastructure.Data
{
    public class SqlOrderRepository : IOrderRepository
    {
        private readonly string _connectionString;

        public SqlOrderRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("Sql");
        }

        public async Task SaveAsync(Order order)
        {
            const string sql = @"
            INSERT INTO Orders (Id, Customer, Product, Qty, Price)
            VALUES (@Id, @Customer, @Product, @Qty, @Price);";

            using var conn = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@Id", order.Id);
            cmd.Parameters.AddWithValue("@Customer", order.CustomerName);
            cmd.Parameters.AddWithValue("@Product", order.ProductName);
            cmd.Parameters.AddWithValue("@Qty", order.Quantity);
            cmd.Parameters.AddWithValue("@Price", order.UnitPrice);

            await conn.OpenAsync();
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
