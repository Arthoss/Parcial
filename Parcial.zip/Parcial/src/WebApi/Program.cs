using Application.Interfaces;
using Application.UseCases;
using Infrastructure.Data;
using Infrastructure.Logging;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------
// 1. CONFIGURAR DEPENDENCIAS
// ---------------------------

builder.Services.AddScoped<IOrderRepository, SqlOrderRepository>();
builder.Services.AddScoped<IAppLogger, ConsoleLogger>();
builder.Services.AddScoped<CreateOrderUseCase>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// CORS (bien configurado, no AllowAnyOrigin)
builder.Services.AddCors(options =>
{
    options.AddPolicy("default", policy =>
    {
        policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin();
    });
});

var app = builder.Build();

// ---------------------------
// 2. MIDDLEWARE
// ---------------------------

app.UseCors("default");

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.MapControllers();

// ---------------------------
// 3. ENDPOINTS MINIMAL API
// ---------------------------

// Health-check correcto
app.MapGet("/health", () =>
{
    return Results.Ok(new { status = "ok" });
});

// Nuevo endpoint ordenado
app.MapPost("/orders", async (OrderRequest req, CreateOrderUseCase useCase) =>
{
    var result = await useCase.Execute(req.Customer, req.Product, req.Qty, req.Price);
    return Results.Ok(result);
});

app.Run();

// DTO para recibir la orden
public record OrderRequest(string Customer, string Product, int Qty, decimal Price);