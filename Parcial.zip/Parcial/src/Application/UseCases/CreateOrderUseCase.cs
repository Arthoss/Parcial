using System;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Entities;

namespace Application.UseCases
{
    public class CreateOrderUseCase
    {
        private readonly IOrderRepository _repository;
        private readonly IAppLogger _logger;

        public CreateOrderUseCase(IOrderRepository repository, IAppLogger logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<Order> Execute(string customer, string product, int qty, decimal price)
        {
            _logger.Log("Starting CreateOrderUseCase...");

            var order = new Order
            {
                Id = Random.Shared.Next(1, 9999999),
                CustomerName = customer,
                ProductName = product,
                Quantity = qty,
                UnitPrice = price
            };

            await _repository.SaveAsync(order);

            return order;
        }
    }
}
