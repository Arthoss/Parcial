using System.Threading.Tasks;
using Domain.Entities;

namespace Application.Interfaces
{
    public interface IOrderRepository
    {
        Task SaveAsync(Order order);
    }
}

