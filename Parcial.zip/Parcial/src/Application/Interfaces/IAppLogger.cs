namespace Application.Interfaces;

public interface IAppLogger
{
    void Log(string message);
}
